package com.example.tinyllamaai

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.*
import android.media.MediaRecorder

class AIService : Service(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var handler: Handler? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
        tts = TextToSpeech(this, this)
        handler = Handler(Looper.getMainLooper())
        startEchoLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundService() {
        val channelId = "AIServiceChannel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "AI Service Channel", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = Notification.Builder(this, channelId)
            .setContentTitle("TinyLlamaAI Echo")
            .setContentText("AI is running (echo mode)")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        startForeground(1, notification)
    }

    private fun startEchoLoop() {
        handler?.postDelayed(object : Runnable {
            override fun run() {
                val fakeInput = "Hello human, I am alive in echo mode."
                speak(fakeInput)
                handler?.postDelayed(this, 15000)
            }
        }, 5000)
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("AIService", "TTS language not supported")
            }
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AIResponse")
        }
    }
}
